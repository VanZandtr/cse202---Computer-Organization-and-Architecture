/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_435(unsigned x)
{
    return x + 3351742792U;
}

unsigned addval_412(unsigned x)
{
    return x + 2421720023U;
}

unsigned getval_292()
{
    return 2462550344U;
}

unsigned getval_423()
{
    return 2428995912U;
}

unsigned addval_281(unsigned x)
{
    return x + 3347662868U;
}

unsigned getval_338()
{
    return 3281031192U;
}

unsigned addval_427(unsigned x)
{
    return x + 2430124086U;
}

void setval_388(unsigned *p)
{
    *p = 2425378869U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_105(unsigned x)
{
    return x + 3229143433U;
}

unsigned getval_371()
{
    return 3524841865U;
}

unsigned addval_129(unsigned x)
{
    return x + 3222851977U;
}

unsigned getval_137()
{
    return 2425409161U;
}

unsigned addval_362(unsigned x)
{
    return x + 3353381192U;
}

unsigned addval_236(unsigned x)
{
    return x + 3224424073U;
}

void setval_151(unsigned *p)
{
    *p = 3682910921U;
}

unsigned getval_102()
{
    return 3281047945U;
}

unsigned addval_121(unsigned x)
{
    return x + 3677930153U;
}

unsigned addval_378(unsigned x)
{
    return x + 3230974601U;
}

void setval_443(unsigned *p)
{
    *p = 3532967561U;
}

unsigned getval_467()
{
    return 3227569801U;
}

unsigned addval_479(unsigned x)
{
    return x + 3380920985U;
}

unsigned getval_125()
{
    return 3531919001U;
}

unsigned getval_276()
{
    return 3767077001U;
}

unsigned getval_287()
{
    return 3281113481U;
}

void setval_265(unsigned *p)
{
    *p = 1321456041U;
}

unsigned addval_480(unsigned x)
{
    return x + 3281047177U;
}

unsigned addval_297(unsigned x)
{
    return x + 3286272330U;
}

void setval_313(unsigned *p)
{
    *p = 3221803401U;
}

unsigned getval_100()
{
    return 3676885385U;
}

unsigned addval_107(unsigned x)
{
    return x + 3223375529U;
}

void setval_367(unsigned *p)
{
    *p = 3223372425U;
}

unsigned addval_191(unsigned x)
{
    return x + 3374367369U;
}

unsigned addval_237(unsigned x)
{
    return x + 3286272328U;
}

unsigned getval_208()
{
    return 3281044107U;
}

unsigned getval_228()
{
    return 3767091437U;
}

unsigned addval_293(unsigned x)
{
    return x + 3229925897U;
}

void setval_363(unsigned *p)
{
    *p = 2496563566U;
}

unsigned getval_491()
{
    return 3286276424U;
}

unsigned addval_175(unsigned x)
{
    return x + 3286272328U;
}

unsigned getval_377()
{
    return 2464188744U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
